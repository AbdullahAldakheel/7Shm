<!DOCTYPE html>
<html lang="en">

    
<?php include'source/head.php'; ?>
  <body>
      
    <!-- Navigation -->
<?php include 'source/nav.php'; ?>

 <!-- Start Edit  -->

<p>  test  </p>
      
      
      
    <!-- Stop -->
    <!-- Footer -->
<?php include'source/footer.php'; ?>


       


  </body>

</html>
