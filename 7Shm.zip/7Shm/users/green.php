<?php  if(count($green) > 0 ): ?>
<div class="greenmess">
    <?php foreach ($green as $green): ?>
    <p> <?php echo $green; ?> </p>
    <?php endforeach ?>
</div>
<?php endif ?>
