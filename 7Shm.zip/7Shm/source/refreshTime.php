

<div class="container">
    <p class="m-0 text-center text-white" > <span id="refreshTime"></span></p>
</div>